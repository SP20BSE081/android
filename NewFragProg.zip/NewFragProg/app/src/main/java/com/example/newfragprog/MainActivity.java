package com.example.newfragprog;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;

import android.content.res.Configuration;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements LeftFragment.LeftFragCommInterface {
    private FragmentManager fragmentManager;
    private LeftFragment leftFragment;
    private RightFragment rightFragment;
    private DataViewModel dataViewModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        int orientation = getResources().getConfiguration().orientation;

        dataViewModel = new ViewModelProvider(this).get(DataViewModel.class);
        dataViewModel.initialize();

        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

            leftFragment = LeftFragment.newInstance();
            rightFragment = RightFragment.newInstance();

            fragmentTransaction.replace(R.id.LeftFL, leftFragment);
            fragmentTransaction.replace(R.id.RightFL, rightFragment);

            fragmentTransaction.commit();
        }
    }

    @Override
    public void sendMessage(String message) {
        rightFragment.setMessage(message);
    }
}