package com.example.newfragprog;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class DataViewModel extends ViewModel {
    private MutableLiveData<String> mutableLiveData;
     private String message;

     public void initialize(){
         mutableLiveData= new MutableLiveData<>();
     }

    public void setMessage(String message) {
        mutableLiveData.setValue(message);
    }
    public MutableLiveData<String> getMessage(){
         return mutableLiveData;
    }
}
