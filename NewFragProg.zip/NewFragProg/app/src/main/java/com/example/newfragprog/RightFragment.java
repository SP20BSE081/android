package com.example.newfragprog;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


public class RightFragment extends Fragment {
    private TextView RightFTV;
    private DataViewModel dataViewModel;
    private Button buttonc;
    public RightFragment() {
        // Required empty public constructor
    }


    public static RightFragment newInstance() {
        RightFragment fragment = new RightFragment();

        return fragment;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        dataViewModel = new ViewModelProvider((MainActivity)context).get(DataViewModel.class);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_right, container, false);
        RightFTV = view.findViewById(R.id.RightFTV);
        buttonc = view.findViewById(R.id.buttonc);
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();

        MutableLiveData<String> mutableLiveData = dataViewModel.getMessage();
        mutableLiveData.observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(String s) {
                RightFTV.setText(s);
            }
        });
    }

    public void setMessage(String message){
        RightFTV.setText(dataViewModel.getMessage());
        //dataViewModel.getMessage();
        //RightFTV.setText(message);
    }
}